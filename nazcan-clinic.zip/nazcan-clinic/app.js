// Utility: format currency IDR
const fmt = n => new Intl.NumberFormat('id-ID', {style:'currency', currency:'IDR', maximumFractionDigits:0}).format(n);

// Theme toggle
const root = document.documentElement;
const themeBtn = document.getElementById('toggleTheme');
const savedTheme = localStorage.getItem('theme');
if(savedTheme==='dark'){ root.classList.add('dark'); }
themeBtn.addEventListener('click', ()=>{
  root.classList.toggle('dark');
  localStorage.setItem('theme', root.classList.contains('dark') ? 'dark' : 'light');
});

// Year
document.getElementById('year').textContent = new Date().getFullYear();

// Slider
const slidesEl = document.getElementById('slides');
let idx = 0;
const prev = document.querySelector('.slide-nav.prev');
const next = document.querySelector('.slide-nav.next');
function go(i){
  const total = slidesEl.children.length;
  idx = (i + total) % total;
  slidesEl.scrollTo({left: slidesEl.clientWidth*idx, behavior:'smooth'});
}
prev.addEventListener('click', ()=> go(idx-1));
next.addEventListener('click', ()=> go(idx+1));
setInterval(()=>go(idx+1), 5000);

// Reveal on scroll
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => e.isIntersecting && e.target.classList.add('visible'));
},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

// To top
const toTop = document.getElementById('toTop');
window.addEventListener('scroll', ()=>{
  if (scrollY > 600) toTop.classList.add('show'); else toTop.classList.remove('show');
});
toTop.addEventListener('click', ()=> window.scrollTo({top:0,behavior:'smooth'}));

// Simple cart
const cart = JSON.parse(localStorage.getItem('nazcan_cart')||'[]');
const cartBtn = document.getElementById('cartBtn');
const cartCount = document.getElementById('cartCount');
const cartDrawer = document.getElementById('cartDrawer');
const cartItems = document.getElementById('cartItems');
const cartTotal = document.getElementById('cartTotal');
const summaryItems = document.getElementById('summaryItems');
const summaryTotal = document.getElementById('summaryTotal');

function saveCart(){ localStorage.setItem('nazcan_cart', JSON.stringify(cart)); renderCart(); renderSummary(); }
function addItem(item){
  const found = cart.find(i=>i.id===item.id);
  if(found){ found.qty += 1; } else { cart.push({...item, qty:1}); }
  saveCart();
}
function removeItem(id){
  const idx = cart.findIndex(i=>i.id===id);
  if(idx>-1){ cart.splice(idx,1); saveCart(); }
}
function changeQty(id, delta){
  const it = cart.find(i=>i.id===id);
  if(!it) return;
  it.qty += delta;
  if(it.qty<=0) removeItem(id); else saveCart();
}
function total(){ return cart.reduce((s,i)=> s + i.price*i.qty, 0); }

function renderCart(){
  cartCount.textContent = cart.reduce((s,i)=>s+i.qty,0);
  cartItems.innerHTML = cart.map(i=>`
    <li>
      <div><strong>${i.name}</strong><br><span class="muted">${fmt(i.price)} × ${i.qty}</span></div>
      <div style="display:flex;gap:6px;align-items:center;">
        <button class="btn pill" onclick="changeQty('${i.id}',-1)">−</button>
        <button class="btn pill" onclick="changeQty('${i.id}',1)">+</button>
        <button class="btn ghost" onclick="removeItem('${i.id}')">🗑️</button>
      </div>
    </li>
  `).join('');
  cartTotal.textContent = fmt(total());
}
function renderSummary(){
  summaryItems.innerHTML = cart.map(i=>`<li>${i.name} — ${i.qty} × ${fmt(i.price)}</li>`).join('') || '<li class="muted">Belum ada item.</li>';
  summaryTotal.textContent = fmt(total());
}
renderCart(); renderSummary();

// Open/close drawer
cartBtn.addEventListener('click', ()=> cartDrawer.classList.add('active'));
document.getElementById('closeCart').addEventListener('click', ()=> cartDrawer.classList.remove('active'));
document.querySelector('.drawer-backdrop').addEventListener('click', ()=> cartDrawer.classList.remove('active'));

// Add to cart buttons
document.querySelectorAll('.add-to-cart').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    addItem({ id: btn.dataset.id, name: btn.dataset.name, price: Number(btn.dataset.price) });
    cartDrawer.classList.add('active');
  });
});

// Appointment form (demo)
document.getElementById('appointmentForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  alert(`Permintaan janji terkirim!\nNama: ${data.nama}\nTanggal: ${data.tanggal}\nKami akan menghubungi: ${data.telp}`);
  e.target.reset();
});

// Checkout form (demo)
document.getElementById('checkoutForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  if(cart.length===0){ alert('Keranjang kosong. Tambahkan layanan terlebih dahulu.'); return; }
  const data = Object.fromEntries(new FormData(e.target).entries());
  const order = {
    id: 'NZ'+Date.now(),
    items: cart,
    total: total(),
    patient: data,
    createdAt: new Date().toISOString()
  };
  localStorage.setItem('nazcan_last_order', JSON.stringify(order));
  // Clear cart
  localStorage.removeItem('nazcan_cart');
  cart.length = 0;
  renderCart(); renderSummary();
  alert('Pesanan diterima! Kode: '+order.id+'\nTim kami akan menghubungi via WA/email untuk pembayaran.');
  // Optional: scroll to top
  window.scrollTo({top:0,behavior:'smooth'});
});

// Expose helpers for inline handlers
window.changeQty = changeQty;
window.removeItem = removeItem;
